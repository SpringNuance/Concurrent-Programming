package reactortest;

class IntIPCHandle extends IPCHandle<Integer> {
	IntIPCHandle() {
		super(-1);
	}
}
