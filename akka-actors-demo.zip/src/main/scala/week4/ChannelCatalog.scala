package week4

import akka.actor.{Actor, ActorLogging, ActorRef, Props}

import scala.collection.immutable

class ChannelCatalog extends Actor with ActorLogging {

  private var channels: immutable.Map[String, ActorRef] = Map()

  override def receive: Receive = {
    case CreateChannel(channel) => addChannel(channel)
    case GetChannelList() => sender ! ChannelList(channels)
    case e => log.error("unknown message " + e.toString)
  }

  private def addChannel(channelName: String): Unit = {
    val channelRef = context.actorOf(ChatChannel.props(channelName), name = channelName)
    channels = channels + (channelName -> channelRef)

    log.info(s"added channel named: ${channelName}")
  }

}
