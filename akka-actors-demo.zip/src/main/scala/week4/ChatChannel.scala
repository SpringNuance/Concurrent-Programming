package week4

import akka.actor.{Actor, ActorLogging, Props}

class ChatChannel(val channelName: String) extends Actor with ActorLogging {
  log.info(s"channel ${channelName} is now online")

  override def receive: Receive = {
    case SendChatMessage(msg, sender) => log.info(s"received message '${msg}' from ${sender.toString}")
    case e => log.error("unknown message " + e.toString)
  }

}

object ChatChannel {

  def props(n: String): Props = Props(new ChatChannel(n))

}