package week4

import akka.actor.{Actor, ActorLogging}

class ChatClient extends Actor with ActorLogging {

  override def receive: Receive = ???

}
