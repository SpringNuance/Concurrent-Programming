package week4

import akka.actor.{ActorSystem, Props}
import akka.pattern.ask
import akka.util.Timeout

import java.util.concurrent.TimeUnit
import scala.language.postfixOps
import scala.concurrent.duration.DurationInt

object ChatDemo extends App {

  val system = ActorSystem("chat-system")
  implicit val timeout = Timeout(5 seconds)
  implicit val context = system.dispatcher

  val channelServer = system.actorOf(Props[ChannelCatalog](), "channel-catalog")

  channelServer ! CreateChannel("cat-memes")
  channelServer ! CreateChannel("dog-videos")

  val rsp = channelServer ? GetChannelList()
  rsp.mapTo[ChannelList].onComplete(x => system.log.info(x.get.channels.toString))

  //let the actor system run and process messages for a while
  TimeUnit.SECONDS.sleep(10)
  system.terminate()
}
