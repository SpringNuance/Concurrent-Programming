package week4

import akka.actor.ActorRef

case class GetChannelList()

case class ChannelList(channels: Map[String, ActorRef])

case class CreateChannel(name: String)

case class JoinChannel(username: String)

case class SendChatMessage(contents: String, sender: Option[ActorRef])

case class ReceiveChatMessage(channel: String, message: String)
