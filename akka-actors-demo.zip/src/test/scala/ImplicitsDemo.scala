import org.scalatest.funsuite.AnyFunSuite

class ImplicitsDemo extends AnyFunSuite {

  abstract class AddOp[A] {
    def add(x: A, y: A): A
    def nil: A
  }

  implicit val IntAddOp: AddOp[Int] = new AddOp[Int] {
    override def add(x: Int, y: Int): Int = x + y
    override def nil: Int = 0
  }

  implicit val StringAddOp: AddOp[String] = new AddOp[String] {
    override def add(x: String, y: String): String = {
      val sb: StringBuilder = new StringBuilder()
      sb.append(x)
      sb.append(y)
      sb.toString
    }
    override def nil: String = ""
  }

  def sumOf[A](items: List[A])(implicit op: AddOp[A]): A = {
    if(items.isEmpty) op.nil
    else op.add(items.head, sumOf(items.tail))
  }

  test("implicit operators demo") {
    assertResult(5)(sumOf(List(1, 1, 1, 1, 1)))
    assertResult(6)(sumOf(List(1, 2, 3)))

    assertResult("abc")(sumOf(List("a", "b", "c")))
  }
}
