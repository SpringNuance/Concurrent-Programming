// 123456 Familyname, Firstname

package hangman

class HangmanGame(val hiddenWord: String, val initialGuessCount: Int) {

  //TODO implement

}

object HangmanGame {

  def main(args: Array[String]): Unit = ???

}